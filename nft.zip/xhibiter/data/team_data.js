const team_data = [
	{
		id: '0CEO, Director',
		image: '/images/team/team_1.jpg',
		title: 'CEO, Director',
		name: 'Alex Grey',
	},
	{
		id: '1Entrepreneur & Author',
		image: '/images/team/team_2.jpg',
		title: 'Entrepreneur & Author',
		name: 'Ashton Kutsher',
	},
	{
		id: '2Developer & Investor',
		image: '/images/team/team_3.jpg',
		title: 'Developer & Investor',
		name: 'John Ferris',
	},
	{
		id: '3Former COO Shopee',
		image: '/images/team/team_4.jpg',
		title: 'Former COO Shopee',
		name: 'Belinda Bing',
	},
	{
		id: '4Chief Creative officer',
		image: '/images/team/team_5.jpg',
		title: 'Chief Creative officer',
		name: 'Camille Alforque',
	},
	{
		id: '5Front-end Developer',
		image: '/images/team/team_6.jpg',
		title: 'Front-end Developer',
		name: 'Nathaniel Ragpa',
	},
	{
		id: '6Marketing Officer',
		image: '/images/team/team_7.jpg',
		title: 'Marketing Officer',
		name: 'Linda Brown',
	},
	{
		id: '7Designer & Investor',
		image: '/images/team/team_8.jpg',
		title: 'Designer & Investor',
		name: 'Gavin Silberman',
	},
	{
		id: '8VP Communications',
		image: '/images/team/team_9.jpg',
		title: 'VP Communications',
		name: 'Masha Smith',
	},
];

export { team_data };
