const ArtData = [
	{
		id: 0,
		bigImage: '/images/products/item_12_lg.jpg',
		userImage: '/images/avatars/avatar_17_rounded.jpg',
		name: 'Light Bars',
		title: 'Wow Frens',
	},
	{
		id: 1,
		bigImage: '/images/products/item_13_lg.jpg',
		userImage: '/images/avatars/avatar_18_rounded.gif',
		name: 'Etherium NFT Launching Lab',
		title: '051_Hart',
	},
	{
		id: 2,
		bigImage: '/images/products/item_16_lg.jpg',
		userImage: '/images/avatars/avatar_22_rounded.jpg',
		name: 'Oceania \\ OVERSEER 017',
		title: 'MadeByM1KE',
	},
	{
		id: 3,
		bigImage: '/images/products/item_14_lg.jpg',
		userImage: '/images/avatars/avatar_19_rounded.jpg',
		name: 'Amazing NFT art',
		title: 'Lila Spacex',
	},
	{
		id: 4,
		bigImage: '/images/products/item_15_lg.jpg',
		userImage: '/images/avatars/avatar_20_rounded.jpg',
		name: 'SwagFox#133',
		title: 'Bored Bunny',
	},
];

export default ArtData;
