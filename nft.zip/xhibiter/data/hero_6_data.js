export const hero_6_data = [
	{
		id: '0Amazing NFT art',
		img: '/images/products/item_14_square.jpg',
		title: 'Amazing NFT art',
		authorName: 'by NFT stars',
	},
	{
		id: '1Amazing NFT art',
		img: '/images/products/item_27_square.jpg',
		title: 'Amazing NFT art',
		authorName: 'by Lazy Panda',
	},
	{
		id: '2Punkie Cat',
		img: '/images/products/item_28_square.jpg',
		title: 'Punkie Cat',
		authorName: 'by NFT stars',
	},
	{
		id: '3VR Space_283',
		img: '/images/products/item_29_square.jpg',
		title: 'VR Space_283',
		authorName: 'by Origin Morish',
	},
	{
		id: '4TSARÉVNA',
		img: '/images/products/item_20_square.jpg',
		title: 'TSARÉVNA',
		authorName: 'CryptoGuysNFT',
	},
	{
		id: '5Metasmorf',
		img: '/images/products/item_30_square.jpg',
		title: 'Metasmorf',
		authorName: 'by Lazy Panda',
	},
	{
		id: '6VR Space_286',
		img: '/images/products/item_25.jpg',
		title: 'VR Space_286',
		authorName: 'by Origin Morish',
	},
	{
		id: '7PankySkal',
		img: '/images/products/item_31_square.jpg',
		title: 'PankySkal',
		authorName: 'by NFT stars',
	},
	{
		id: '8VR Space_287',
		img: '/images/products/item_32_square.jpg',
		title: 'VR Space_287',
		authorName: 'by Origin Morish',
	},
];
