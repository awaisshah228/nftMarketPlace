import React from 'react';

const user_details = () => {
	return <div>user_details</div>;
};

export default user_details;
